/* 
 /* console.log("hola")
 log es una funcion nativa de la consola 

let a = 1; 
let b = 5;

Boolean /* puede ser treue o false


parsear:
promt();
cuando metes los datos los traduce a string

parseInt();
*/
/* 
let a = 1; 
let b = 5;
let c = "hola";

console.log(c,a,b);

if(a==b){
    console.log(5);
}else{
    console.log(6)
}
 */

/* 
switch(a){
    case 1:
    console.log("es correcto");
    break;
    case 2:
    console.log(" no es correcto");
    break;
    case 3:
        console.log(" no es correcto");
    break;
} */ 

let a = 7;
let b =10;
let c = 5;

if((a+b+c)/3 <= 7){
    console.log("has suspendido")
}else{
    console.log("has aprobado")
}








